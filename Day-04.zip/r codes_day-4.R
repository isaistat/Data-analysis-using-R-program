# Load required package
library(tidyverse)

# Read the data
data <- read.csv("D:/R basic class/Daywise_class/Daywise/Day-4/nhanes_data.csv")
head(data)

# **Creating New Variables Using ONE Existing Variable**
data <- data %>%
  mutate(
    age_in_months = Age * 12,  # Age in months (useful for age-related calculations)
    age_in_days   = Age * 365,  # Age in days (can be used for more granular age-based analysis)
    cholesterol_log = log(TotChol)  # Log transformation on cholesterol (used for distribution normalization)
  )

# Display table for newly created variables
table(data$age_in_months)
table(data$age_in_days)
table(data$cholesterol_log)

# **Creating New Variables Using TWO Existing Variables**
data <- data %>%
  mutate(
    bmi_calculated = Weight / (Height / 100)^2,  # BMI calculation (used to assess obesity)
    pressure_ratio = BPSys / BPDia,  # Systolic/diastolic ratio (helps evaluate blood pressure behavior)
    age_bmi_ratio  = Age / bmi_calculated  # Age-to-BMI ratio (used to analyze weight-related age effects)
  )

# Display table for newly created variables
table(data$bmi_calculated)
table(data$pressure_ratio)
table(data$age_bmi_ratio)

# **Creating New Variables Using THREE Existing Variables**
data <- data %>%
  mutate(
    bmi_adjusted = (Weight / (Height / 100)^2) * (Age / BPSys)  # Adjusted BMI considering age and systolic BP
  )

# Display table for newly created variable
table(data$bmi_adjusted)

# **Creating Logical Variables from Calculations**
data <- data %>%
  mutate(
    overweight_flag = bmi_calculated >= 25,  # Flag for overweight status (BMI ≥ 25 indicates overweight)
  )

# Display table for newly created logical variables
table(data$overweight_flag)

# **Using `ifelse()`**
data <- data %>%
  mutate(
    elderly_status  = ifelse(Age >= 60, "Elderly", "Non-elderly"),
    overweight_yn = ifelse(bmi_calculated >= 25, "Yes", "No"),
  )

# Display table for newly created variables
table(data$elderly_status)
table(data$overweight_yn)

# **Creating Categories Using cut() (Fixed Cut-offs) for Categorizing Continuous Variables**
data <- data %>%
  mutate(
    bmi_category = cut(
      bmi_calculated,
      breaks = c(0, 18.5, 25, 30, 100),
      labels = c("Underweight", "Normal", "Overweight", "Obese")  # Categorizing BMI (common clinical classification)
    ),
    age_group = cut(
      Age,
      breaks = c(0, 40, 60, 120),
      labels = c("Young", "Middle-aged", "Elderly")  # Age groups (used to assess risks based on age)
    )
  )

# Display table for newly created categorical variables
table(data$bmi_category)
table(data$age_group)

# **Creating Categories Using `case_when()`**
# Example: Very Simple (Age Category)
data <- data %>%
  mutate(
    age_category = case_when(
      Age < 18  ~ "Pediatric",
      Age < 65  ~ "Adult",
      TRUE      ~ "Senior"
    )
  )

# Display table for newly created variable
table(data$age_category)

# Example: Simple classification using Pulse
data <- data %>%
  mutate(
    pulse_category = case_when(
      Pulse < 60  ~ "Low pulse",  # Below 60 beats per minute
      Pulse >= 60 & Pulse <= 100 ~ "Normal pulse",  # Normal pulse range (60-100 bpm)
      Pulse > 100 ~ "High pulse"  # Above 100 beats per minute
    )
  )

# Display table for newly created variable
table(data$pulse_category)

# Example: Simple binary (single variable) - High Cholesterol
data <- data %>%
  mutate(
    high_cholesterol = case_when(
      TotChol >= 240 ~ "Yes",  # Total cholesterol >= 240 mg/dL indicates high cholesterol
      TRUE           ~ "No"
    )
  )

# Display table for newly created variable
table(data$high_cholesterol)

# Example: Moderate complexity - Income Category
data <- data %>%
  mutate(
    income_category = case_when(
      HHIncomeMid < 20000 ~ "Low income",  # Low income group
      HHIncomeMid >= 20000 & HHIncomeMid < 75000 ~ "Medium income",  # Medium income group
      HHIncomeMid >= 75000 ~ "High income"  # High income group
    )
  )

# Display table for newly created variable
table(data$income_category)

# Risk classification based on age and systolic blood pressure
data <- data %>%
  mutate(
    hypertension_risk = case_when(
      BPSys >= 140 ~ "High risk",  # High systolic BP indicates high risk
      BPSys >= 120 ~ "Moderate risk",  # Pre-hypertension stage
      TRUE            ~ "Low risk"
    )
  )

# Display table for newly created variable
table(data$hypertension_risk)

# Example: Moderate (Two Variables, Clinical Logic) - Health Risk
data <- data %>%
  mutate(
    health_risk = case_when(
      Age >= 60 & Diabetes == "Yes" ~ "High risk",  # Older age and diabetes increases risk
      Age >= 40 | Diabetes == "Yes"  ~ "Moderate risk",  # Either factor contributes to moderate risk
      TRUE                           ~ "Low risk"
    )
  )

# Display table for newly created variable
table(data$health_risk)

# Example: Slightly Advanced (Multiple Clinical Factors) - Cardiovascular Risk
data <- data %>%
  mutate(
    cardio_risk = case_when(
      bmi_calculated >= 30 & BPSys >= 140 & TotChol >= 240 ~ "Very high risk",  # High BMI, BP, and cholesterol
      bmi_calculated >= 25 & BPSys >= 140                   ~ "High risk",  # High BMI and BP
      TotChol >= 240                                           ~ "Moderate risk",  # High cholesterol alone
      TRUE                                                     ~ "Low risk"
    )
  )

# Display table for newly created variable
table(data$cardio_risk)

# **Recoding Values**
data <- data %>%
  mutate(Gender = recode(Gender, "male" = "M", "female" = "F"))
# Display table for newly recoded values
table(data$Gender)

# **Grouped Recoding**
data <- data %>%
  group_by(Gender) %>%
  mutate(order_sex = row_number()) %>%
  ungroup()
# Display table for newly created grouped variable
table(data$order_sex)

data <- data %>%
  group_by(Gender) %>%
  mutate(
    med_sbp = median(BPSys, na.rm = TRUE),  # Median systolic blood pressure by gender
    age_bp_risk = ifelse(Age >= med_sbp, "higher_risk", "lower_risk")  # Age vs median systolic BP risk
  ) %>%
  ungroup()
# Display table for newly created grouped variable
table(data$med_sbp)
table(data$age_bp_risk)

