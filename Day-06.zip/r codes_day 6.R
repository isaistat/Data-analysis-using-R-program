# Exploratory Data Analysis (EDA) in R – Descriptives, Tables, and Plots

# Load required libraries
library(tidyverse)
library(skimr)
library(janitor)
# To install

library(tableone)
library(DescTools)
library(summarytools)
library(gmodels)

??pbc
help(pbc)

# Descriptive Statistics: Continuous Variables

pbc <- read.csv("D:/R basic class/Daywise_class/Daywise/Day-06/PBC_data.csv")
skim(pbc)
str(pbc)


summary(pbc)
summary(pbc$age)

# Manual Descriptive Measures with base

mean(pbc$age, na.rm = TRUE)
mean(pbc$platelet,na.rm = TRUE)

median(pbc$age, na.rm = TRUE)
range(pbc$age, na.rm = TRUE)
IQR(pbc$age, na.rm = TRUE)
sd(pbc$age, na.rm = TRUE)

# Data Cleaning and Recoding

library(tidyverse)
table(pbc$trt)
pbc <- pbc %>%
  mutate(
    trt = factor(trt, levels = c(1,2),
                 labels = c("D-penicillamine","Placebo")
                 ),
    
    
    status = factor(status,
                    levels = c(0,1,2),
                    labels = c("Censored","Transplant","Death")),
    
    
    sex = factor(sex,
                 levels = c("f","m"),
                 labels = c("Female","Male")),
    
    
    ascites = factor(ascites, levels = c(0,1), labels = c("No","Yes")),
    hepato = factor(hepato, levels = c(0,1), labels = c("No","Yes")),
    spiders = factor(spiders, levels = c(0,1), labels = c("No","Yes")),
    edema = factor(edema,
                   levels = c(0,0.5,1),
                   labels = c("No edema",
                              "Edema despite diuretics",
                              "Edema no diuretics")),
    stage = factor(stage)
  )

str(pbc)
head(pbc)

library(skimr)
skim(pbc)

# Descriptive measure with packages

library(DescTools)
Desc(pbc)
Desc(pbc$time)

library(summarytools)
descr(pbc)
descr(pbc$bili)

# Group-wise Summaries using group_by()

pbc %>%
  group_by(status) %>%
  summarise(
    mean_age   = mean(age, na.rm = TRUE),
    median_age = median(age, na.rm = TRUE),
    sd_age     = sd(age, na.rm = TRUE),
    n          = n()
  )

pbc %>%
  group_by(trt) %>%
  summarise(
    mean_bili = mean(bili, na.rm = TRUE),
    med_bili = median(bili, na.rm = TRUE),
    n = n()
  ) %>% 
  mutate(perc=n/418)

# Descriptive Statistics: Categorical Variables

tab_sex <- table(pbc$sex)

tab_sex
prop.table(tab_sex) * 100

table(pbc$sex)

library(janitor)
tabyl(pbc$sex)

# Frequency Tables and Crosstabs

t1 <- table(pbc$sex, pbc$status)
t1
prop.table(t1, 1) * 100

t2 <- xtabs(~pbc$sex + pbc$status) %>% addmargins()
t2

tabyl(dat=pbc, sex, status)

tabyl(pbc, sex, status) %>%
  adorn_percentages("col") %>%
  adorn_pct_formatting(digits = 2)

tabyl(pbc, sex, status) %>%
  adorn_totals(c("row","col"))

library(gmodels)

CrossTable(pbc$sex, pbc$status)

CrossTable(
  pbc$sex, pbc$status,
  prop.r = TRUE,
  prop.c = TRUE,
  prop.t = TRUE,
  prop.chisq = FALSE,
  chisq = TRUE
)

# Using package tableone for Clinical Descriptives

library(tableone)

var_set <- c("age", "bili", "albumin", "sex", "ascites", "stage")

CreateTableOne(vars = var_set, data = pbc)
CreateTableOne(vars = names(pbc), data = pbc)

shapiro.test(pbc$age) #<0.05 its not normal

vars <- c("age", "bili", "albumin", "sex", "ascites", "stage")

t1 <- CreateTableOne(
  vars   = var_set,
  strata = "trt",
  data   = pbc
)
print(t1, showAllLevels = TRUE)


t2 <- CreateTableOne(
  vars = names(pbc),
  strata = "trt",
  data = pbc
)
print(t2, showAllLevels = TRUE)

vars <- c("age", "bili", "albumin", "sex", "ascites", "stage")

t1 = CreateTableOne(
  vars   = var_set,
  strata = "trt",
  addOverall = TRUE,
  test = TRUE,
  data   = pbc
)
print(t1, showAllLevels = TRUE)

t2 <- CreateTableOne(
  vars = names(pbc),
  strata = "trt",
  addOverall = TRUE,
  test = TRUE,
  data = pbc
)
print(t2, showAllLevels = TRUE)

t2 <- CreateTableOne(
  vars = names(pbc),
  strata = "trt",
  addOverall = TRUE,
  test = TRUE,
  data = pbc
)
print(t2, showAllLevels = TRUE,
      nonnormal=c("age","bili"))

tab_print <- print(t2, showAllLevels = TRUE,nonnormal=c("age","bili"), 
                   printToggle = FALSE)

write.csv(tab_print, "baseline_table.csv", na = "")


# Correlation Analysis

cor(
  pbc$age, pbc$bili,
  use = "complete.obs",
  method = "pearson"
)

cor(
  pbc$age, pbc$bili,
  use = "complete.obs",
  method = "spearman"
)

plot(pbc$age~pbc$bili)
hist(pbc$age)
hist(pbc$bili)
boxplot(pbc$bili)

