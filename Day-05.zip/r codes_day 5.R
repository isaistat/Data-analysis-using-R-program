# Set working directory
setwd("D:/R basic class/Daywise_class/Daywise/Day-05")

# Load packages
library(dplyr)
library(openxlsx)

# Read Excel sheets
data1 <- read.xlsx("merge_sample.xlsx", sheet = "data1")
data2 <- read.xlsx("merge_sample.xlsx", sheet = "data2")
daily_visit <- read.xlsx("merge_sample.xlsx", sheet = "daily_visit")
daily_visit2 <- read.xlsx("merge_sample.xlsx", sheet = "daily_visit_2")

# Preview data
head(data1)
head(data2)
head(daily_visit)

# Check duplicates before joining
duplicated(data1$id)
duplicated(data2$id)

# ----------------------------
# INNER JOIN
# ----------------------------

merge(data1, data2, by = "id")
inner_join(data1, data2, by = "id")

# ----------------------------
# LEFT JOIN
# ----------------------------

merge(data1, data2, by = "id", all.x = TRUE)
left_join(data1, data2, by = "id")

# ----------------------------
# RIGHT JOIN
# ----------------------------

merge(data1, data2, by = "id", all.y = TRUE)
right_join(data1, data2, by = "id")

# ----------------------------
# FULL JOIN
# ----------------------------

merge(data1, data2, by = "id", all = TRUE)
full_join(data1, data2, by = "id")

# ----------------------------
# ANTI JOIN
# ----------------------------

anti_join(data1, data2, by = "id")

# ----------------------------
# ONE-TO-ONE (1:1)
# ----------------------------

merge(data1, data2, by = "id")

# ----------------------------
# ONE-TO-MANY (1:m)
# ----------------------------

merge(data1, daily_visit, by = "id")

# ----------------------------
# MANY-TO-ONE (m:1)
# ----------------------------

merge(daily_visit, data1, by = "id")

# ----------------------------
# MANY-TO-MANY (m:m)
# ----------------------------

merge(daily_visit, daily_visit2, by = "id")