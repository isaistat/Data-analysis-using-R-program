# Q1 – Structure & numeric variable count
str(nhanes)
sum(sapply(nhanes, is.numeric))

# Q2 – Check & convert Age safely
if(!is.numeric(nhanes$Age)){
  nhanes$Age <- as.numeric(nhanes$Age)
}

# Q3 – Convert Gender & Diabetes to factor
nhanes$Gender <- as.factor(nhanes$Gender)
nhanes$Diabetes <- as.factor(nhanes$Diabetes)

levels(nhanes$Gender)
levels(nhanes$Diabetes)

# Q4 – Dataset dimensions
dim(nhanes)
nrow(nhanes)
ncol(nhanes)

# Q5 – Total missing values
sum(is.na(nhanes))

# Q6 – Variable with highest missing
missing_counts <- colSums(is.na(nhanes))
missing_counts
names(which.max(missing_counts))
missing_counts[which.max(missing_counts)]

# Q7 – Convert InterviewDate_1 safely
nhanes$InterviewDate_1 <- as.Date(nhanes$InterviewDate_1)

nhanes$InterviewYear <- year(nhanes$InterviewDate_1)

# Q8 – Convert LabDateTime safely
nhanes$LabDateTime <- as.POSIXct(
  nhanes$LabDateTime,
  format="%Y-%m-%d %H:%M:%S",
  tz="UTC"
)

nhanes$LabHour <- hour(nhanes$LabDateTime)

# Q9 – Convert SmokeNow to logical properly
nhanes$SmokeNow <- ifelse(nhanes$SmokeNow == "Yes", TRUE,
                          ifelse(nhanes$SmokeNow == "No", FALSE, NA))

# Q10 – Export cleaned file
write.csv(nhanes, "nhanes_clean_day2.csv", row.names = FALSE)

# -------------------------------------------------------------------------

# Q1 – Select variables
nhanes %>%
  select(Age, Gender, BPSysAve, TotChol)

# Q2 – Select range
nhanes %>%
  select(Age:HHIncomeMid)

# Q3 – Exclude SmokeNow
nhanes %>%
  select(-SmokeNow)

# Q4 – Arrange ascending Age
nhanes %>%
  arrange(Age)

# Q5 – Arrange descending BP
nhanes %>%
  arrange(desc(BPSysAve))

# Q6 – Filter Age > 60
nhanes %>%
  filter(Age > 60)

# Q7 – Diabetic & Hypertensive
nhanes %>%
  filter(Diabetes == "Yes" & BPSysAve >= 140)

# Q8 – High cholesterol OR obese
nhanes %>%
  filter(TotChol >= 240 | BMI_WHO == "Obese")

# Q9 – Select columns for diabetics
nhanes %>%
  filter(Diabetes == "Yes") %>%
  select(Age, Gender, BPSysAve)

# Q10 – Elderly sorted by cholesterol
nhanes %>%
  filter(Age >= 60) %>%
  arrange(desc(TotChol))

# -------------------------------------------------------------------------

# Q1 – Age in months
nhanes <- nhanes %>%
  mutate(Age_in_months = Age * 12)

# Q2 – Safe BMI calculation
nhanes <- nhanes %>%
  mutate(
    BMI_calc = ifelse(!is.na(Weight) & !is.na(Height),
                      Weight / (Height/100)^2,
                      NA)
  )

# Q3 – Hypertension flag
nhanes <- nhanes %>%
  mutate(Hypertension_flag = BPSysAve >= 140)

# Q4 – Age group
nhanes <- nhanes %>%
  mutate(
    Age_group = case_when(
      Age < 40 ~ "Young",
      Age >= 40 & Age < 60 ~ "Middle-aged",
      Age >= 60 ~ "Elderly"
    )
  )

# Q5 – Cholesterol status
nhanes <- nhanes %>%
  mutate(
    Cholesterol_status = case_when(
      TotChol >= 240 ~ "High",
      TRUE ~ "Normal"
    )
  )

# Q6 – Income category
nhanes <- nhanes %>%
  mutate(
    Income_category = case_when(
      HHIncomeMid < 20000 ~ "Low",
      HHIncomeMid >= 20000 & HHIncomeMid < 75000 ~ "Medium",
      HHIncomeMid >= 75000 ~ "High"
    )
  )

# Q7 – Improved Cardio risk
nhanes <- nhanes %>%
  mutate(
    Cardio_risk = case_when(
      Age >= 60 & BPSysAve >= 140 ~ "High risk",
      BPSysAve >= 140 ~ "Moderate risk",
      BPSysAve >= 120 ~ "Elevated",
      TRUE ~ "Normal"
    )
  )

# Q8 – Metabolic risk
nhanes <- nhanes %>%
  mutate(
    Metabolic_risk = case_when(
      BMI_calc >= 30 & TotChol >= 240 ~ "High",
      TRUE ~ "Low"
    )
  )

# Q9 – Gender median BP comparison
nhanes <- nhanes %>%
  group_by(Gender) %>%
  mutate(
    Gender_median_BP = median(BPSysAve, na.rm = TRUE),
    BP_relative_risk = ifelse(BPSysAve > Gender_median_BP,
                              "Above median",
                              "Below median")
  ) %>%
  ungroup()

# Q10 – Composite high-risk patient
nhanes <- nhanes %>%
  mutate(
    High_risk_patient = case_when(
      Diabetes == "Yes" |
        BPSysAve >= 140 |
        TotChol >= 240 ~ "Yes",
      TRUE ~ "No"
    )
  )