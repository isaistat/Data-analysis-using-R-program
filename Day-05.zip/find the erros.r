# ---------------------------------------------------------
# Load Required Packages & Data
# ---------------------------------------------------------
library(dplyr)
library(lubridate)

nhanes <- read.csv("nhanes.csv", stringsAsFactors = FALSE)

# ---------------------------------------------------------
# 1. Mean Age – Missing na.rm
# ---------------------------------------------------------
mean(nhanes$Age)
# ERROR: Returns NA if missing values exist
# ANSWER:
# mean(nhanes$Age, na.rm = TRUE)


# ---------------------------------------------------------
# 2. Filtering with = instead of ==
# ---------------------------------------------------------
nhanes %>% filter(Diabetes = "Yes")
# ERROR: '=' assigns value instead of comparing
# ANSWER:
# nhanes %>% filter(Diabetes == "Yes")


# ---------------------------------------------------------
# 3. Case Sensitivity Error
# ---------------------------------------------------------
nhanes %>% filter(age > 60)
# ERROR: Column 'age' not found
# ANSWER:
# nhanes %>% filter(Age > 60)


# ---------------------------------------------------------
# 4. Wrong Logical Operator
# ---------------------------------------------------------
nhanes %>% filter(Age > 60 && BPSysAve >= 140)
# ERROR: '&&' works only for single logical value
# ANSWER:
# nhanes %>% filter(Age > 60 & BPSysAve >= 140)


# ---------------------------------------------------------
# 5. Mutate Without Assignment
# ---------------------------------------------------------
nhanes %>% mutate(BMI_calc = Weight / (Height/100)^2)
# ERROR: Changes not saved
# ANSWER:
# nhanes <- nhanes %>% mutate(BMI_calc = Weight / (Height/100)^2)


# ---------------------------------------------------------
# 6. Wrong Date Format
# ---------------------------------------------------------
nhanes$InterviewDate_1 <- as.Date(nhanes$InterviewDate_1, format="%d/%m/%Y")
# ERROR: Wrong format if data is YYYY-MM-DD
# ANSWER:
# nhanes$InterviewDate_1 <- as.Date(nhanes$InterviewDate_1)


# ---------------------------------------------------------
# 7. Logical Conversion Mistake
# ---------------------------------------------------------
nhanes$SmokeNow <- as.logical(nhanes$SmokeNow)
# ERROR: Converts "Yes"/"No" to NA
# ANSWER:
# nhanes$SmokeNow <- ifelse(nhanes$SmokeNow == "Yes", TRUE,
#                           ifelse(nhanes$SmokeNow == "No", FALSE, NA))


# ---------------------------------------------------------
# 8. Missing Parenthesis
# ---------------------------------------------------------
nhanes %>% filter((Age > 60 & BPSysAve >= 140)
# ERROR: Missing closing parenthesis
# ANSWER:
# nhanes %>% filter((Age > 60 & BPSysAve >= 140))


# ---------------------------------------------------------
# 9. Selecting Non-Existing Column
# ---------------------------------------------------------
nhanes %>% select(Age, BP)
# ERROR: Column 'BP' does not exist
# ANSWER:
# nhanes %>% select(Age, BPSysAve)


# ---------------------------------------------------------
# 10. case_when Without Default Condition
# ---------------------------------------------------------
nhanes <- nhanes %>%
  mutate(Risk = case_when(
    BPSysAve >= 140 ~ "High"
  ))
# ERROR: Missing TRUE condition, remaining rows become NA
# ANSWER:
# nhanes <- nhanes %>%
#   mutate(Risk = case_when(
#     BPSysAve >= 140 ~ "High",
#     TRUE ~ "Normal"
#   ))