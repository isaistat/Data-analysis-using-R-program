
# PBC – Graph Selection Based on Decision Tree
# One example per concept + one customized version


library(ggplot2)
library(dplyr)
library(janitor)
library(scales)

pbc <- read.csv("D:/R basic class/Daywise_class/Daywise/Day-06/PBC_data.csv")

pbc <- pbc %>%
  mutate(
    trt = factor(trt, levels = c(1,2),
                 labels = c("D-penicillamine","Placebo")),
    
    
    status = factor(status,
                    levels = c(0,1,2),
                    labels = c("Censored","Transplant","Death")),
    
    
    sex = factor(sex,
                 levels = c("f","m"),
                 labels = c("Female","Male"))
  )


##################### ONE VARIABLE #########################


################# 1A – CATEGORICAL #########################
colors() #To check all the colors in the R

"red" # When u write the color name correctly the the word will highlighted with that color

# Basic Bar
ggplot(data=pbc, aes(x=sex)) +
  geom_bar(color="indianred1",fill="khaki1")+
  labs(x="Sex",y="Count",title = "Sex distribution")+
  theme_test()



# Customized
ggplot(pbc, aes(x = sex)) +
  geom_bar(color="indianred1",fill="khaki1",width = 0.4) +
  geom_text(stat = "count",
            aes(label = ..count..),
            vjust = 1, hjust=0.5,
            size = 5)+
  labs(x="Sex",y="Count",title = "Sex distribution")+
  theme_test()


library(janitor)
tabl_sex <- tabyl(pbc,sex)

ggplot(data=tabl_sex,aes(x=sex,y=n))+
  geom_col(color="indianred1",fill="khaki1")+
  geom_text(aes(label=percent))+
  labs(x="Sex",y="Count",title = "Sex distribution")+
  theme_test()



tabl_status <- tabyl(pbc,status)
tabl_status$perc <- paste(round(tabl_status$percent,3)*100,"%", sep="")


ggplot(data=tabl_status,aes(x=status,y=n))+
  geom_col(color="indianred1",fill="khaki1")+
  geom_text(aes(label=perc))+
  labs(x="Status",y="Count",title = "Sex distribution")+
  theme_test()


################# Pie Chart #########################

ggplot(pbc, aes(x="", fill=status)) +
  geom_bar(width=1) +
  geom_text(stat = "count",
            aes(label = ..count..),
            vjust = 1,
            size = 5)+
  
  coord_polar("y") +
  theme_void()

################# Pareto Chart #########################

stage_table <- tabyl(pbc, stage) %>% arrange(desc(n))

ggplot(stage_table, aes(x=reorder(stage, -n), y=n)) +
  geom_col()

ggplot(stage_table, aes(x=reorder(stage, -n),y= n)) +
  geom_col(fill="steelblue",color="red") +
  geom_text(aes(label=n))+
  geom_line(aes(group=1), color="red") +
  theme_minimal()

################# 1B – CONTINUOUS #########################

# Histogram
ggplot(pbc, aes(x=albumin)) +
  geom_histogram(bins=10,color="red",fill="blue")

ggplot(pbc, aes(albumin)) +
  geom_histogram(bins=25, fill="skyblue", color="black") +
  theme_minimal()

# Density
ggplot(pbc, aes(albumin)) +
  geom_density()

ggplot(pbc, aes(albumin)) +
  geom_density(fill="lightgreen", alpha=0.4) +
  theme_minimal()

# Boxplot
ggplot(pbc, aes(y=bili)) +
  geom_boxplot()

ggplot(pbc, aes(y=bili)) +
  geom_boxplot(fill="orange") +
  theme_minimal()

