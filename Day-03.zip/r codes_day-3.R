# Load required packages
library(tidyverse)
library(mlbench)

# Load Pima dataset
data(data)

# View structure
str(data)
#Selecting Variables---------------------------
# Select specific columns
data %>% 
  select(age, bmi, glucose)

# Select range of columns
data %>% 
  select(pregnant:age)

# Exclude a column
data %>% 
  select(-insulin)

#Sorting the Data---------------------------
# Ascending order by age
data %>% 
  arrange(age)

# Descending order by glucose
data %>% 
  arrange(desc(glucose))

#Renaming Variables---------------------------
# Rename one variable
data <- data %>% 
  rename(BMI = bmi)

# Rename multiple variables
data <- data %>% 
  rename(
    Glucose = glucose,
    BloodPressure = pressure
  )

#Filtering Rows (Handling Missing Values)---------------------------
# Keep rows without missing BMI
data %>% 
  filter(!is.na(bmi))

# Keep rows with missing BMI
data %>% 
  filter(is.na(bmi))

# Check if any missing values exist
any(is.na(data))

#Filtering with Conditions
# Age greater than 50
data %>% 
  filter(age > 50)

# Age > 50 AND diabetes = positive
data %>% 
  filter(age > 50 & diabetes == "pos")

# Glucose > 140 OR BMI > 30
data %>% 
  filter(glucose > 140 | bmi > 30)

# Diabetes not positive
data %>% 
  filter(diabetes != "pos")