#To see all the sample dataset 
data()

## ---------------------------------------------------------
## Importing NHANES Data
## ---------------------------------------------------------

nhanes <- read.csv("D:/R basic class/Daywise_class/NHANES_data.csv")
# ---------------------------------------------------------
# Viewing and Exploring the Dataset
# ---------------------------------------------------------
View(nhanes)
head(nhanes)
tail(nhanes)

dim(nhanes)
nrow(nhanes)
ncol(nhanes)

names(nhanes) #Will give the variable names in the data
str(nhanes)
class(nhanes)
class(nhanes$InterviewDate_1)

## ---------------------------------------------------------
## Understanding and Changing Data Types (NHANES Variables)
## ---------------------------------------------------------

## Numeric variables
is.numeric(nhanes$Age)
nhanes$Age <- as.numeric(nhanes$Age)

is.numeric(nhanes$HHIncomeMid)
nhanes$HHIncomeMid <- as.numeric(nhanes$HHIncomeMid)
nhanes$HHIncome <- as.numeric(nhanes$HHIncomeMid)

is.numeric(nhanes$BPSysAve)
nhanes$BPSysAve <- as.numeric(nhanes$BPSysAve)

## Character variables
is.character(nhanes$Race1)
nhanes$Race1 <- as.character(nhanes$Race1)

## Logical variables (example: current smoker)
is.logical(nhanes$SmokeNow)
nhanes$SmokeNow <- as.logical(nhanes$SmokeNow)
View(nhanes)

## Factor (categorical) variables
nhanes$Gender <- as.factor(nhanes$Gender)
nhanes$Race <- as.factor(nhanes$Race)
nhanes$Diabetes <- as.factor(nhanes$Diabetes)
nhanes$BMI_WHO <- as.factor(nhanes$BMI_WHO)

levels(nhanes$Gender)
table(nhanes$Gender)
prop.table(table(nhanes$Gender)) * 100

## ---------------------------------------------------------
## Date, Time, and Datetime Handling (NHANES Context)
## ---------------------------------------------------------

## Interview date (Date)
class(nhanes$InterviewDate_1)

nhanes$InterviewDate_1 <- as.Date(nhanes$InterviewDate_1,
                                  format = "%m/%d/%Y")

nhanes$InterviewDate_2 <- as.Date(nhanes$InterviewDate_2,
                                  formal = "%d-%m-%Y")

## Laboratory datetime (Date + Time)
class(nhanes$LabDateTime)
nhanes$LabDateTime <- as.POSIXct(
  nhanes$LabDateTime,
  format = "%d-%m-%Y %H:%M:%S",
  tz = "UTC"
)

## Mixed date formats (teaching example)
library(lubridate)
nhanes$InterviewDate_3 <- parse_date_time(nhanes$InterviewDate_3,
                                          orders = c("ymd", "mdy", "dmy", "dmy HMS", "ymd HMS")
)

View(nhanes)
#Change the format we wish
library(lubridate)

nhanes$InterviewDate_yr  <- year( nhanes$InterviewDate_1)
nhanes$InterviewDate_m <- month( nhanes$InterviewDate_1)
nhanes$InterviewDate_m <- month( nhanes$InterviewDate_1,label = TRUE,abbr = TRUE)
nhanes$InterviewDate_m <- month( nhanes$InterviewDate_1,label = TRUE,abbr = FALSE)

nhanes$LabHour   <- hour(nhanes$LabDateTime)
nhanes$LabMinute <- minute(nhanes$LabDateTime)

getwd()
# copy paste your file path
setwd("D:/R basic class/Daywise_class") 
#Exporting
write.csv(nhanes, "updated_data.csv", na = "")
library(openxlsx)
write.xlsx(data, "updated_data.xlsx", na = "")

## ---------------------------------------------------------
## Identifying Missing Values
## ---------------------------------------------------------
any(is.na(nhanes))
colSums(is.na(nhanes))

## ---------------------------------------------------------
## Skimming the Data
## ---------------------------------------------------------
library(skimr)
skim(nhanes)
